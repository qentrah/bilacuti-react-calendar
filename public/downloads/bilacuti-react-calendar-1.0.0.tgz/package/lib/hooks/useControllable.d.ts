export declare function useControllable<T>(value: T | undefined, initialValue: T, onChange?: (value: T) => void): readonly [T, (value: T) => void];
