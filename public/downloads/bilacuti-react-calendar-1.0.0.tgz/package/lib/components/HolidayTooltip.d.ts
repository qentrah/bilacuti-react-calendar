import { CalendarEvent, CalendarTheme } from '../types.js';
export interface HolidayTooltipProps {
    id: string;
    anchor: HTMLElement;
    events: readonly CalendarEvent[];
    theme: CalendarTheme;
    onDismiss: () => void;
}
/** Body portal avoids sticky-toolbar stacking contexts and container clipping. */
export declare function HolidayTooltip({ id, anchor, events, theme, onDismiss, }: HolidayTooltipProps): import('react').ReactPortal;
