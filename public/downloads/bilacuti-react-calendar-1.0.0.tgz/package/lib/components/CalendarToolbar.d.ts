import { CalendarTheme, CalendarView, HolidayVisibility, WeekStart } from '../types.js';
export interface CalendarToolbarProps {
    years: number[];
    year: number;
    onYearChange: (year: number) => void;
    selectedStates: string[];
    onStatesChange: (states: string[]) => void;
    view: CalendarView;
    onViewChange: (view: CalendarView) => void;
    theme: CalendarTheme;
    onThemeChange: (theme: CalendarTheme) => void;
    weekStart: WeekStart;
    onWeekStartChange: (start: WeekStart) => void;
    visibility: HolidayVisibility;
    onVisibilityChange: (visibility: HolidayVisibility) => void;
}
export declare function CalendarToolbar(props: CalendarToolbarProps): import('react').JSX.Element;
