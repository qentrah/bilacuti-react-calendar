import { CalendarEvent, CalendarTheme, CalendarView, WeekStart } from '../types.js';
export interface CalendarGridProps {
    year: number;
    events: readonly CalendarEvent[];
    view: Exclude<CalendarView, "list">;
    weekStart: WeekStart;
    theme: CalendarTheme;
    idPrefix: string;
    onDateSelect?: (date: string, events: CalendarEvent[]) => void;
}
export declare function CalendarGrid({ year, events, view, weekStart, theme, idPrefix, onDateSelect, }: CalendarGridProps): import('react').JSX.Element;
