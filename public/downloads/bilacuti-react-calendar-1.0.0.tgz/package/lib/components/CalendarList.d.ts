import { CalendarEvent } from '../types.js';
export interface CalendarListProps {
    events: readonly CalendarEvent[];
}
export declare function CalendarList({ events }: CalendarListProps): import('react').JSX.Element;
