export declare function CalendarRelatedLinks({ year }: {
    year: number;
}): import('react').JSX.Element;
export declare function CalendarFooter(): import('react').JSX.Element;
