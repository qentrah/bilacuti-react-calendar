export interface CalendarIconProps {
    type?: "grid" | "month" | "list" | "settings";
}
export declare function CalendarIcon({ type }: CalendarIconProps): import('react').JSX.Element;
