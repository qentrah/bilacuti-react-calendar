import { CalendarEvent, HolidayVisibility, HolidayYear } from './types.js';
/** Empty selection means all states; nationwide restricts public holidays only. */
export declare function filterCalendarEvents(data: HolidayYear, selected: readonly string[], visibility: HolidayVisibility): CalendarEvent[];
export declare function eventsOnDate(events: readonly CalendarEvent[], date: string): CalendarEvent[];
export declare function monthOffset(year: number, month: number, sundayFirst: boolean): number;
export declare function dateKey(year: number, month: number, day: number): string;
