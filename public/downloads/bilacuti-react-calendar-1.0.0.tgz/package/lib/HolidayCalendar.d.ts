import { HolidayCalendarProps } from './types.js';
/** Standalone calendar. No document styles, URL mutations, or app-level side effects. */
export declare function HolidayCalendar(props: HolidayCalendarProps): import('react').JSX.Element;
