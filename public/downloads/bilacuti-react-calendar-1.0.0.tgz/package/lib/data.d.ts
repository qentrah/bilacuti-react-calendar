import { HolidayDataset } from './types.js';
/** Source-derived Malaysian holidays for 2026 and 2027. */
export declare const malaysiaHolidayData: HolidayDataset;
export declare const states: {
    slug: string;
    name: string;
}[];
export declare const schoolGroupA: string[];
export declare const schoolGroupB: string[];
export declare const monthNames: string[];
export declare function regionName(region: string): string;
